
# formdata_js_php
Subir foto con JavaScript + FormData + Fetch hacia PHP

# Más información
Post explicativo: [Cargar archivo a PHP desde JavaScript con FormData](https://parzibyte.me/blog/2018/11/06/cargar-archivo-php-javascript-formdata/)

![enter image description here](https://i1.wp.com/parzibyte.me/blog/wp-content/uploads/2018/11/Subir-archivos-con-JavaScript-fetch-y-FormData-a-PHP.gif?resize=750,567&ssl=1)

# Probar código fuente
Eres libre de descargarlo y probarlo en tu entorno local. Aquí un [tutorial para instalar XAMPP en Windows 10](https://parzibyte.me/blog/2017/12/11/configurar-instalar-php-7-apache-server-mysql-windows/).
